public class check_all_ex {
}
