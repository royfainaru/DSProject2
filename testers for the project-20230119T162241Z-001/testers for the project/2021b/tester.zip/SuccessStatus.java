/**
 * Created by kalevalp on 11-Jan-15.
 */
public enum SuccessStatus {
    FAIL, PASS, EXCEPTION
}
